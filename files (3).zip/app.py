import json, urllib.request, urllib.error, os
from flask import Flask, request, jsonify, send_file
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

BINA_URL = "https://webfiles.binaw.com/post/PostJsonDocV2.aspx"
TOKEN    = "76b37357660475442296bc1b40140c54a63711ceacee30002af04286f21fc460-Shilat3583"

@app.route('/')
def index():
    for path in ['index.html', 'static/index.html']:
        if os.path.exists(path):
            return send_file(path)
    return "index.html not found", 404

@app.route('/health')
def health():
    return jsonify({"status": "ok"})

@app.route('/bina', methods=['POST', 'OPTIONS'])
def proxy():
    if request.method == 'OPTIONS':
        return '', 204
    body = request.get_json(force=True) or {}
    body['tokenId'] = TOKEN
    print(f"[BINA] Sending: {json.dumps(body)[:150]}")
    try:
        d   = json.dumps(body).encode()
        req = urllib.request.Request(
            BINA_URL, data=d, method='POST',
            headers={
                'Content-Type': 'application/json',
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)',
                'Accept': 'application/json, text/plain, */*',
                'Accept-Language': 'he-IL,he;q=0.9',
                'Origin': 'https://webapps.binaw.com',
                'Referer': 'https://webapps.binaw.com/'
            }
        )
        with urllib.request.urlopen(req, timeout=30) as r:
            raw = r.read().decode('utf-8', 'replace')
        print(f"[BINA] Response ({len(raw)} chars): {raw[:300]}")
        try:
            pj    = json.loads(raw)
            items = pj if isinstance(pj, list) else pj.get('items', []) if isinstance(pj, dict) else []
            parsed = {'type': 'json', 'items': items}
        except:
            parsed = {'type': 'bina_star', 'items': []} if raw.startswith('*') else {'type': 'unknown', 'items': []}
        return jsonify({'success': True, 'parsed': parsed, 'raw': raw})
    except urllib.error.HTTPError as e:
        err = f"HTTP {e.code}: {e.read().decode()[:200]}"
        print(f"[BINA] HTTPError: {err}")
        return jsonify({'success': False, 'error': err}), 500
    except Exception as e:
        print(f"[BINA] Error: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5050))
    app.run(host='0.0.0.0', port=port)
